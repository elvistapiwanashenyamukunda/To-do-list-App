const inputBox = document.getElementById("input-box");
const listContainer = document.getElementById("list-container");
// code that will be executed when the button 'add' is clicked
function addTask(){
    // check if input box is empty
    if(inputBox.value === ''){
        // if it is empty then the user will get the write something prompt
        alert("You Must Write Something First!!!");
    }
    // check if input box has something
    else{
        // create HTML element with the tagname 'li' and the element is stored in the 'li' variable
        let li = document.createElement("li");
        // we add the text to the 'li' and that is the same text we will have entered in the input field
        li.innerHTML = inputBox.value;
        // displaying under List container
        listContainer.appendChild(li);
        // add X icon with span
        let span = document.createElement("span");
        // add content to span
        span.innerHTML="\u00d7";
        // display span
        li.appendChild(span);
    }
    // clear input field after adding text
    inputBox.value = "";
    // save dat each time
    saveData();
}

// deleting text and crossing tasks
listContainer.addEventListener("click", function(e){
    // checks if we have clicked on LI
    if(e.target.tagName === "LI"){
        // removes
        e.target.classList.toggle("checked");
        saveData();
    }
    // checks if we have clicked on a span
    else if(e.target.tagName === "SPAN"){
        // deletes element or task
        e.target.parentElement.remove();
        saveData();
    }
}, false);
// save data
function saveData(){
    localStorage.setItem("data",listContainer.innerHTML);
}
// display saved data
function showTasks(){
    listContainer.innerHTML=localStorage.getItem("data");
}
showTasks();